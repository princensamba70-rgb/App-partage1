import { randomUUID } from 'node:crypto';
import type pg from 'pg';
import { z } from 'zod';
import { pool } from './db.js';
import { AppError } from './errors.js';
import type { AnswerInstance, AnswerMap } from './survey-solutions.service.js';

export const ruleTypes = ['min','max','range','equals','not_equals','allowed','required','format','min_length','max_length','compare','consistency','duplicate'] as const;
export type RuleType = typeof ruleTypes[number];
const value = z.union([z.string().max(500), z.number().finite(), z.boolean()]);
const uuid = z.string().uuid();
const numeric = z.number().finite();
const schemas: Record<RuleType, z.ZodTypeAny> = {
  min: z.object({ value: numeric }), max: z.object({ value: numeric }),
  range: z.object({ min: numeric, max: numeric }).refine(x => x.min <= x.max, 'Le minimum doit etre <= au maximum.'),
  equals: z.object({ value }), not_equals: z.object({ value }),
  allowed: z.object({ values: z.array(value).min(1).max(100) }),
  required: z.object({}),
  format: z.object({ kind: z.enum(['integer','decimal','date','phone','email','text']) }),
  min_length: z.object({ value: z.number().int().min(0).max(10000) }),
  max_length: z.object({ value: z.number().int().min(0).max(10000) }),
  compare: z.object({ otherQuestionId: uuid, operator: z.enum(['<','<=','>','>=','==','!=']) }),
  consistency: z.object({ whenQuestionId: uuid, operator: z.enum(['==','!=']), value }),
  duplicate: z.object({ questionIds: z.array(uuid).min(1).max(10) }),
};
export const rulePayload = z.object({ questionId: uuid, type: z.enum(ruleTypes), params: z.unknown(), active: z.boolean().default(true) }).strict();
export function parseRule(payload: unknown) {
  const data = rulePayload.parse(payload);
  return { ...data, params: schemas[data.type].parse(data.params) as Record<string, unknown> };
}
export async function validateReferences(client: pg.PoolClient, rule: ReturnType<typeof parseRule>, excludeId?: string) {
  const target = await client.query('SELECT version_id FROM questions WHERE id=$1', [rule.questionId]);
  if (!target.rowCount) throw new AppError(404, 'QUESTION_ABSENTE', 'Question introuvable.');
  const params = rule.params;
  const refs = rule.type === 'compare' ? [params.otherQuestionId] :
    rule.type === 'consistency' ? [params.whenQuestionId] : rule.type === 'duplicate' ? params.questionIds : [];
  for (const id of refs as string[]) {
    if (id === rule.questionId || id === excludeId) throw new AppError(400, 'QUESTION_INVALIDE', 'Sélectionnez une autre question.');
    const other = await client.query('SELECT version_id FROM questions WHERE id=$1', [id]);
    if (!other.rowCount || other.rows[0].version_id !== target.rows[0].version_id) throw new AppError(400, 'QUESTION_INVALIDE', 'Les questions liées doivent appartenir à la même version du questionnaire.');
  }
  return target.rows[0].version_id as string;
}

export type QualityQuestion = { id: string; variable_name: string; type: string; enabling_condition: string | null; is_roster: boolean };
export type QualityRule = { id: string; question_id: string; type: RuleType; params: Record<string, any> };
export type QualityResponse = { id: string; external_id: string; answers: AnswerMap };
export type RuleResult = { status: 'CONFORME' | 'NON CONFORME' | 'NON CONTRÔLÉ'; errorType: string | null; details: string };
const passed = (message = 'Contrôle réussi.') : RuleResult => ({ status: 'CONFORME', errorType: null, details: message });
const failed = (type: string, message: string): RuleResult => ({ status: 'NON CONFORME', errorType: type, details: message });
const unchecked = (message = 'Réponse absente ou question non applicable.') : RuleResult => ({ status: 'NON CONTRÔLÉ', errorType: null, details: message });
const empty = (v: unknown) => v == null || typeof v === 'string' && !v.trim() || Array.isArray(v) && !v.length;
const same = (a: unknown, b: unknown) => String(a).trim() === String(b).trim();
const number = (v: unknown): number | null => {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  if (typeof v !== 'string' || !/^-?(?:\d+)(?:[.,]\d+)?$/.test(v.trim())) return null;
  const n = Number(v.trim().replace(',', '.'));
  return Number.isFinite(n) ? n : null;
};
function evaluateFormat(kind: string, input: unknown): boolean {
  const str = String(input).trim();
  switch (kind) {
    case 'integer': return /^-?\d+$/.test(str);
    case 'decimal': return number(input) !== null;
    case 'date': {
      if (!/^\d{4}-\d{2}-\d{2}(?:T.*)?$/.test(str)) return false;
      const date = new Date(str);
      return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === str.slice(0, 10);
    }
    case 'phone': return /^\+?[0-9][0-9 .()\-]{6,18}$/.test(str);
    case 'email': return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str);
    case 'text': return typeof input === 'string';
    default: return false;
  }
}
function getAnswers(response: QualityResponse, question: QualityQuestion): AnswerInstance[] {
  const entries = response.answers[question.variable_name];
  return Array.isArray(entries) ? entries : [];
}
function findRelated(response: QualityResponse, target: QualityQuestion | undefined, vector: number[]): AnswerInstance | undefined {
  if (!target) return undefined;
  const entries = getAnswers(response, target);
  return entries.find(e => JSON.stringify(e.rosterVector) === JSON.stringify(vector)) || (vector.length ? entries.find(e => !e.rosterVector.length) : undefined);
}
function compareValues(a: unknown, b: unknown, op: string): boolean | null {
  if (op === '==') return same(a,b);
  if (op === '!=') return !same(a,b);
  const left = number(a), right = number(b);
  if (left === null || right === null) return null;
  return op === '<' ? left < right : op === '<=' ? left <= right : op === '>' ? left > right : left >= right;
}

/** Evaluation deterministic, without executing Survey Solutions C# expressions. */
export function evaluateRule(rule: QualityRule, question: QualityQuestion, response: QualityResponse,
  byId: Map<string, QualityQuestion>, current: AnswerInstance | undefined, duplicateOf?: string): RuleResult {
  const p = rule.params, v = current?.value;
  if (rule.type === 'consistency') {
    const trigger = findRelated(response, byId.get(p.whenQuestionId), current?.rosterVector || []);
    if (!trigger || empty(trigger.value)) return unchecked('Condition non vérifiable : question déclenchante absente.');
    if (!compareValues(trigger.value, p.value, p.operator)) return unchecked('Condition non déclenchée.');
    return empty(v) ? failed('Erreur de cohérence', 'Valeur attendue lorsque la condition est remplie.') : passed('Cohérence vérifiée.');
  }
  if (rule.type === 'required') {
    if (!empty(v)) return passed('Valeur renseignée.');
    // Skip logic et taille des rosters sont des expressions C# non evaluees ici.
    if (question.enabling_condition || question.is_roster) return unchecked('Question conditionnelle ou dans un roster : applicabilité inconnue.');
    return failed('Valeur manquante', 'Cette question doit être renseignée.');
  }
  if (empty(v)) return unchecked();
  if (rule.type === 'duplicate') return duplicateOf ? failed('Doublon potentiel', `Valeurs identiques à l’entretien ${duplicateOf}.`) : passed('Aucun doublon détecté.');
  if (rule.type === 'compare') {
    const other = findRelated(response, byId.get(p.otherQuestionId), current?.rosterVector || []);
    if (!other || empty(other.value)) return unchecked('Question comparée absente.');
    const ok = compareValues(v, other.value, p.operator);
    if (ok === null) return failed('Erreur de format', 'Comparaison numérique impossible.');
    return ok ? passed('Comparaison respectée.') : failed('Erreur de cohérence', `Comparaison ${p.operator} non respectée.`);
  }
  if (rule.type === 'format') return evaluateFormat(p.kind, v) ? passed('Format valide.') : failed('Erreur de format', `Format ${p.kind} invalide.`);
  if (rule.type === 'min_length' || rule.type === 'max_length') {
    const size = String(v).length, ok = rule.type === 'min_length' ? size >= p.value : size <= p.value;
    return ok ? passed('Longueur conforme.') : failed('Erreur de format', `Longueur ${rule.type === 'min_length' ? 'minimale' : 'maximale'} : ${p.value}.`);
  }
  if (rule.type === 'equals') return same(v,p.value) ? passed() : failed('Valeur interdite', `Valeur attendue : ${p.value}.`);
  if (rule.type === 'not_equals') return !same(v,p.value) ? passed() : failed('Valeur interdite', `Valeur interdite : ${p.value}.`);
  if (rule.type === 'allowed') {
    const parts = question.type === 'SÉLECTION MULTIPLE' && typeof v === 'string' ? v.split(',').map(s => s.trim()) : [v];
    return parts.every(item => p.values.some((allow: unknown) => same(allow,item))) ? passed() : failed('Valeur interdite', `Valeurs autorisées : ${p.values.join(', ')}.`);
  }
  const n = number(v);
  if (n === null) return failed('Erreur de format', 'Valeur numérique attendue.');
  const ok = rule.type === 'min' ? n >= p.value : rule.type === 'max' ? n <= p.value : n >= p.min && n <= p.max;
  const detail = rule.type === 'min' ? `Minimum ${p.value}` : rule.type === 'max' ? `Maximum ${p.value}` : `Entre ${p.min} et ${p.max}`;
  return ok ? passed(detail) : failed('Erreur de seuil', detail);
}

function duplicateKey(rule: QualityRule, anchor: QualityQuestion, response: QualityResponse, byId: Map<string, QualityQuestion>): string | null {
  const keys = [anchor.id, ...(rule.params.questionIds as string[])].map(id => byId.get(id));
  if (keys.some(k => !k)) return null;
  const values = keys.map(q => getAnswers(response, q!));
  if (values.some(a => a.length !== 1 || empty(a[0]?.value) || a[0]?.rosterVector.length)) return null;
  return JSON.stringify(values.map(a => String(a[0]!.value).trim().toLowerCase()));
}

export async function reanalyzeVersion(versionId: string, transaction?: pg.PoolClient) {
  const own = !transaction;
  const client = transaction || await pool.connect();
  try {
    if (own) await client.query('BEGIN');
    const questions = (await client.query('SELECT id, variable_name, type, enabling_condition, is_roster FROM questions WHERE version_id=$1', [versionId])).rows as QualityQuestion[];
    const byId = new Map(questions.map(q => [q.id,q]));
    const rules = (await client.query(`SELECT r.id, r.question_id, r.type, r.params FROM quality_rules r JOIN questions q ON q.id=r.question_id
       WHERE q.version_id=$1 AND r.active=true ORDER BY r.created_at,r.id`, [versionId])).rows as QualityRule[];
    const responses = (await client.query('SELECT id, external_id, answers FROM survey_responses WHERE version_id=$1 ORDER BY last_modified_at NULLS LAST, external_id', [versionId])).rows as QualityResponse[];
    await client.query('DELETE FROM quality_results WHERE response_id IN (SELECT id FROM survey_responses WHERE version_id=$1)', [versionId]);
    const duplicateFirst = new Map<string, string>();
    for (const response of responses) {
      let hasPass = false, hasFail = false;
      for (const rule of rules) {
        const question = byId.get(rule.question_id);
        if (!question) continue;
        const instances = getAnswers(response, question);
        let firstId: string | undefined;
        if (rule.type === 'duplicate') {
          const key = duplicateKey(rule, question, response, byId);
          if (key !== null) {
            const index = `${rule.id}:${key}`;
            firstId = duplicateFirst.get(index);
            if (!firstId) duplicateFirst.set(index, response.external_id);
          }
        }
        for (const instance of instances.length ? instances : [undefined]) {
          const checked = rule.type === 'duplicate' && !duplicateKey(rule, question, response, byId)
            ? unchecked('Critères de doublon absents ou multiples.')
            : evaluateRule(rule, question, response, byId, instance, firstId);
          if (checked.status === 'CONFORME') hasPass = true;
          if (checked.status === 'NON CONFORME') hasFail = true;
          const instanceKey = instance?.rosterVector?.length ? instance.rosterVector.join('/') : '';
          await client.query(`INSERT INTO quality_results(id,response_id,question_id,rule_id,instance_key,value,status,error_type,details)
            VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
            [randomUUID(), response.id, question.id, rule.id, instanceKey, instance ? JSON.stringify(instance.value ?? null) : null, checked.status, checked.errorType, checked.details]);
        }
      }
      await client.query('UPDATE survey_responses SET status=$1,analyzed_at=now() WHERE id=$2', [hasFail ? 'NON CONFORME' : hasPass ? 'CONFORME' : 'NON CONTRÔLÉ', response.id]);
    }
    if (own) await client.query('COMMIT');
    return { interviews: responses.length, controls: rules.length };
  } catch (error) { if (own) await client.query('ROLLBACK'); throw error; }
  finally { if (own) client.release(); }
}

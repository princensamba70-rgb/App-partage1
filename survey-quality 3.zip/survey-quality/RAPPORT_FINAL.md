# Rapport final — SurveyQuality

**Date :** 25 septembre 2026  
**Objet :** application de contrôle qualité pour Survey Solutions ; connexion HQ HTTP et diagnostic de démarrage Docker  
**État :** correctifs validés localement ; la cause exacte du `backend is unhealthy` sur la machine du destinataire reste **à confirmer par les journaux**.

## Livrables

- Frontend React/TypeScript responsive avec connexion, tableaux de bord, questionnaires et versions, questions détectées, contrôles, rapports, exports, activité, profil, gestion des utilisateurs et configuration administrateur.
- Backend Node.js/TypeScript : API REST, autorisations par rôle, synchronisation et détection de structure, moteur de règles et réanalyse, rapports, exports CSV/XLSX/PDF, journal d’activité.
- Schéma PostgreSQL : `database/schema.sql` ; volume nommé `postgres_data` dans `docker-compose.yml`.
- Dockerfiles backend/frontend, `.env.example` sans secrets effectifs, `README.md`, tests unitaires frontend/backend, simulateur et parcours d’intégration Docker.

## Vérifications réellement exécutées

| Vérification | Résultat |
| --- | --- |
| `npm run build` backend et frontend | Réussis ; pages frontend découpées en modules chargés à la demande |
| Tests unitaires backend | **29/29 réussis** : moteur qualité, adaptateur HQ, diagnostics API et paramètres PostgreSQL séparés / erreur de mot de passe du volume |
| Tests frontend | **5/5 réussis** : navigation selon rôle, absence de préremplissage, consentement HTTP et affichage d’un refus de workspace |
| `npm audit --omit=dev` dans chaque projet | **0 vulnérabilité signalée** dans les dépendances de production, pour chaque projet |
| `docker compose --profile test build`, `up -d --wait`, puis **`docker compose up -d --build --wait`** | Réussis localement : PostgreSQL, backend et frontend *healthy* ; interface et `/health` en HTTP 200 |
| `GET /health`, `GET /` après démarrage et redémarrage | HTTP **200** pour chaque route |
| `node tests/integration.mjs before` sur base de test neuve | **65 vérifications réussies**, dont test et synchronisation sur `http://...` dans `sankurusaco`, diagnostics 401/403/404 et Swagger indisponible |
| Vérification supplémentaire des exports sur la base de test | **18/18** couples ressource/format ont répondu avec la signature attendue ; XLSX ouvert par `openpyxl` : 9 résultats et en-têtes contrôlés |
| `docker compose --profile test down` puis `up -d --wait` **sans `-v`**, suivi de `node tests/integration.mjs after` | **11 vérifications réussies** ; volume PostgreSQL et autorisation HTTP par connexion intacts |
| Projet Compose isolé avec mot de passe PostgreSQL contenant `@`, `#`, `/`, `$`, `%`, `?`, `:` | PostgreSQL et backend **healthy**, `/health` HTTP 200 ; paramètres séparés, pas d’URI à encoder |
| Même projet : mot de passe `.env` modifié **sans supprimer le volume** | Échec reproduit : PostgreSQL *healthy*, backend redémarre ; journal `[startup] PG_AUTH` explicite et sans secret. Valeur initiale rétablie : backend *healthy*, 2 comptes conservés ; seul le volume de test isolé a ensuite été effacé |
| `node scripts/diagnose.mjs` sur `.env` de test et exemple fictif | Configuration valide acceptée ; valeurs fictives et clé incorrecte signalées **sans afficher les secrets** |
| Migration d’une ancienne table `survey_solutions_config` en base temporaire | Réussie : ancienne ligne conservée, nouvelle colonne ajoutée avec valeur sécurisée par défaut |
| Inspection des journaux après redémarrage | **0 occurrence** de `error`, `fatal` ou `exception` dans l’extrait récent examiné |

Le parcours d’intégration couvre les sessions, le hash bcrypt, les permissions serveur de `user1`, le cycle de vie des comptes et les identifiants Survey Solutions chiffrés et non divulgués. Le correctif vérifie que **HTTP nécessite un accord explicite**, qu’un compte API valide accède réellement à `sankurusaco`, qu’un refus HTTP **403** ne se présente plus comme un mot de passe faux, qu’un **401** reste distinct, et qu’une page de connexion ou un Swagger indisponibles ne font pas échouer à tort la vérification de l’API. Il empêche la réutilisation automatique des identifiants enregistrés sur une autre URL. Le parcours vérifie aussi la synchronisation répétée sans doublon, les règles transactionnelles, les rapports et filtres, le superviseur GraphQL simulé, l’activité, les exports et les lignes PostgreSQL.

**Données constatées en base après deux synchronisations puis redémarrage :** 1 questionnaire, 1 version, 3 sections, 5 questions, 3 entretiens, 3 règles conservées et 9 résultats de contrôle ; 2 échecs de contrôle. Les décomptes persistants vérifiés par SQL sont `1|5|3|3|9` (questionnaires | questions | règles | entretiens | résultats). Le mot de passe initial du compte administrateur était un hash bcrypt ; les identifiants API étaient chiffrés, et non stockés en clair.

## Analyse du message « backend is unhealthy »

Le résumé Compose signifie que le backend ne répond pas correctement au contrôle `/health` ; **il ne contient pas la cause initiale**. L’API Survey Solutions n’est pas nécessaire au démarrage de ce contrôle : une erreur de compte HQ seule n’explique pas ce statut. Les journaux de la machine concernée n’ont pas été fournis, donc aucun diagnostic certain n’est possible pour son installation. Deux causes crédibles sont maintenant prises en charge :

1. Une valeur de `.env.example` conservée ou une clé AES invalide bloque le démarrage : les erreurs indiquent maintenant `CONFIG_INVALIDE`, `CONFIG_COMPTES` ou `CONFIG_CLE`, sans imprimer de valeur ; `node scripts/diagnose.mjs` les repère avant Compose.
2. Un mot de passe PostgreSQL contenant des caractères réservés pouvait être mal interprété dans `DATABASE_URL` ; Compose passe désormais hôte/utilisateur/mot de passe/base **séparément**. Avec un volume déjà initialisé, modifier `POSTGRES_PASSWORD` dans `.env` ne modifie pas le rôle PostgreSQL : ce cas a été **reproduit localement** et signale maintenant `PG_AUTH`. La solution conserve le volume, elle ne le supprime pas.

Le contrôle backend dispose également d’un délai de démarrage plus long pour une initialisation lente. La démarche pour récupérer le code réel figure dans [README.md](README.md), section « Si Compose indique backend is unhealthy ».

## Éléments non validés ou limites

1. **L’URL complète du serveur Survey Solutions cible et ses accès API n’ont pas été fournis** (seul le préfixe HTTP et le nom d’espace `sankurusaco` sont connus). Les appels ont été confrontés au Swagger public de démonstration et exercés contre un simulateur, pas sur le HQ réel. La réussite sur le simulateur **ne prouve pas** la connexion ni la synchronisation sur l’installation du destinataire ; le test doit être relancé avec son URL racine et son compte API, sans jamais transmettre son mot de passe dans un échange d’assistance. Le numéro 26.09 (build 41860) est celui de la démonstration/simulation, pas une affirmation sur son serveur.
2. Un serveur **HTTP** expose l’authentification Basic au réseau sans TLS, même si les identifiants restent chiffrés en base. L’option HTTP demande un consentement explicite et doit rester limitée à un réseau privé fiable ; **HTTPS est fortement recommandé** pour le HQ et pour l’application.
3. L’enrichissement des superviseurs via GraphQL est **facultatif**. Sur une instance sans le schéma attendu, les entretiens REST restent disponibles mais le superviseur peut manquer ; le filtre associé ne sera alors pas complet.
4. Les expressions d’activation et validations avancées propres à Survey Solutions ne sont pas exécutées comme du code local. Les contrôles incertains sont marqués `NON CONTRÔLÉ` afin d’éviter certains faux positifs ; les règles explicites créées dans l’application sont évaluées.
5. Les tests frontend ont été réalisés sous jsdom et le parcours d’intégration est un test HTTP/SQL avec simulateur. **Aucun test automatisé sur navigateur réel ni test de charge** n’a été exécuté. L’audit de sécurité mentionné ci-dessus concerne les dépendances de production, pas une homologation de sécurité globale.
6. TLS, sauvegardes PostgreSQL, politique de conservation des réponses et validation opérationnelle sur l’infrastructure finale restent à organiser avant une mise en production. Les éventuelles évolutions futures du schéma demanderont une stratégie de migrations dédiée.

## Mise en service

Suivre [README.md](README.md) pour la configuration de `.env`, le démarrage Docker, la connexion à une instance Survey Solutions réelle et les commandes de vérification. Ne jamais lancer le script de test ou `docker compose down -v` sur une base à conserver. Protéger les mots de passe de démarrage et la clé AES, puis activer HTTPS et les cookies sécurisés pour un déploiement public.

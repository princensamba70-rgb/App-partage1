import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { api, setToken, getToken } from '../api/client';

export interface User {
  id: number; nom: string; prenom: string; username: string;
  telephone?: string; email?: string; roleId: 'ADMIN' | 'FINANCE' | 'ASSISTANT';
  roleName: string; actif: boolean;
  permissions: Record<string, 'full' | 'read' | 'none'>;
}

interface AuthCtx {
  user: User | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<User>;
  logout: () => Promise<void>;
  can: (module: string, niveau?: 'full' | 'read') => boolean;
  refreshUser: () => Promise<void>;
}

const Ctx = createContext<AuthCtx>(null as any);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshUser = async () => {
    if (!getToken()) { setUser(null); setLoading(false); return; }
    try {
      const d = await api.get('/api/auth/me');
      setUser(d.user);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { refreshUser(); }, []);
  useEffect(() => {
    const onLogout = () => setUser(null);
    window.addEventListener('ap:logout', onLogout);
    return () => window.removeEventListener('ap:logout', onLogout);
  }, []);

  const login = async (username: string, password: string) => {
    const d = await api.post('/api/auth/login', { username, password });
    setToken(d.accessToken);
    setUser(d.user);
    return d.user as User;
  };

  const logout = async () => {
    try { await api.post('/api/auth/logout'); } catch { /* ignore */ }
    setToken(null);
    setUser(null);
  };

  const can = (module: string, niveau: 'full' | 'read' = 'read') => {
    if (!user) return false;
    const p = user.permissions?.[module] || 'none';
    return niveau === 'read' ? p !== 'none' : p === 'full';
  };

  return <Ctx.Provider value={{ user, loading, login, logout, can, refreshUser }}>{children}</Ctx.Provider>;
}

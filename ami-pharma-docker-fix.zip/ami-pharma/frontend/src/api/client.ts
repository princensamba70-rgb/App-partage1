// Client API avec gestion automatique du refresh token
export class ApiError extends Error {
  status: number;
  details?: any;
  constructor(status: number, message: string, details?: any) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

let accessToken: string | null = localStorage.getItem('ap_token');
let refreshPromise: Promise<string | null> | null = null;

export function setToken(t: string | null) {
  accessToken = t;
  if (t) localStorage.setItem('ap_token', t);
  else localStorage.removeItem('ap_token');
}
export function getToken() { return accessToken; }

async function tryRefresh(): Promise<string | null> {
  if (!refreshPromise) {
    refreshPromise = fetch('/api/auth/refresh', { method: 'POST', credentials: 'include' })
      .then(async (r) => {
        if (!r.ok) return null;
        const d = await r.json();
        setToken(d.accessToken);
        return d.accessToken as string;
      })
      .catch(() => null)
      .finally(() => { refreshPromise = null; });
  }
  return refreshPromise;
}

async function request(method: string, url: string, body?: any, retry = true): Promise<any> {
  const headers: Record<string, string> = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (accessToken) headers['Authorization'] = `Bearer ${accessToken}`;

  let res: Response;
  try {
    res = await fetch(url, {
      method, headers, credentials: 'include',
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (networkErr) {
    // Erreur RÉSEAU uniquement (API réellement injoignable : connexion refusée, DNS, hors ligne).
    // Les réponses HTTP (401, 400, 500…) ne passent PAS ici : elles sont traitées ci-dessous
    // avec le message exact du serveur (ex. « Identifiants incorrects »).
    console.error('[api] échec réseau vers', url, networkErr);
    throw new ApiError(0, 'Service backend injoignable (erreur réseau). Vérifiez que l\'API AMI PHARMA est démarrée, puis réessayez.');
  }

  if (res.status === 401 && retry) {
    const t = await tryRefresh();
    if (t) return request(method, url, body, false);
    setToken(null);
    window.dispatchEvent(new CustomEvent('ap:logout'));
    throw new ApiError(401, 'Session expirée');
  }
  if (!res.ok) {
    let msg = `Erreur ${res.status}`;
    let details;
    try { const d = await res.json(); msg = d.error || msg; details = d.details; } catch { /* corps non-JSON : on garde le message par défaut */ }
    if (res.status === 502 || res.status === 503 || res.status === 504) {
      // Proxy/gateway : le backend ne répond pas — message explicite
      msg = msg.startsWith('Service backend') ? msg : `Service backend momentanément injoignable (HTTP ${res.status}). L'API AMI PHARMA démarre ou est arrêtée — réessayez dans quelques secondes.`;
    }
    throw new ApiError(res.status, msg, details);
  }
  if (res.status === 204) return null;
  const ct = res.headers.get('content-type') || '';
  return ct.includes('application/json') ? res.json() : res.text();
}

export const api = {
  get: (url: string) => request('GET', url),
  post: (url: string, body?: any) => request('POST', url, body ?? {}),
  put: (url: string, body?: any) => request('PUT', url, body ?? {}),
  del: (url: string) => request('DELETE', url),
};

// Téléchargement d'un export authentifié (xlsx / pdf / csv)
export async function downloadExport(url: string, filename: string) {
  const headers: Record<string, string> = {};
  if (accessToken) headers['Authorization'] = `Bearer ${accessToken}`;
  const res = await fetch(url, { headers, credentials: 'include' });
  if (!res.ok) throw new ApiError(res.status, 'Échec du téléchargement');
  const blob = await res.blob();
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(a.href);
}

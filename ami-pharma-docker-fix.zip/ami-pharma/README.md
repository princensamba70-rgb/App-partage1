# 🏥 AMI PHARMA — PHARMACY MANAGEMENT SYSTEM

Application web professionnelle, moderne, sécurisée et responsive de gestion complète d'une pharmacie.

**AMI PHARMA** · AVENUE NGUMA N° 3 Q/JOLI PARC C/NGALIEMA · KINSHASA / RDC · Tél : 0820829592 - 0812271621
Devise : **CDF** · Langue : **Français** (architecture prête pour multi-devises / multi-langues)

---

## 🚀 Démarrage avec Docker (recommandé — production)

```bash
cd ami-pharma
cp .env.example .env        # personnalisez les secrets JWT et le mot de passe PostgreSQL
docker compose up --build -d
```

Puis ouvrez **http://localhost:8080**

**Ports hôtes utilisés** (rien d'autre n'est réservé — le port hôte 4000 n'est jamais touché) :

| Service | Port hôte | Port interne conteneur | Rôle |
|---|---|---|---|
| `web` (Nginx) | `WEB_PORT` = **8080** | 80 | Point d'entrée unique de l'application |
| `api` (Node) | `API_PORT` = **4001** | 4000 | Accès direct pour debug (`http://localhost:4001/api/health`) |
| `db` (PostgreSQL) | *aucun* (non publié) | 5432 | Accessible uniquement depuis le réseau Docker interne |

Le port **interne** 4000 de l'API est conservé ; seul le mapping hôte est configurable. Si 4001 est aussi occupé sur votre machine : `API_PORT=4002 docker compose up -d` (ou modifiez `.env`). Les conteneurs communiquent entre eux via les **noms de services** (`api:4000`, `db:5432`) sur le réseau bridge `amipharma` — jamais via les ports hôtes — donc une autre application occupant le port 4000 de l'hôte ne peut pas entrer en conflit avec `amipharma-api`.


Au premier démarrage, le conteneur API :
1. attend que PostgreSQL soit prêt,
2. applique le schéma de base de données (toutes les tables + index),
3. crée les rôles, permissions et comptes initiaux (mots de passe **hachés bcrypt**),
4. importe les **2 826 produits** du catalogue officiel `LISTE DES PRIX(1).pdf` (édition du 24/07/2026, devise CDF),
5. génère les **données de démonstration** : 135 médicaments en stock, 12 approvisionnements (avec lots et dates d'expiration variées), ~400 ventes sur 30 jours, 1 inventaire en cours, rapports journaliers, notifications.

### Comptes créés automatiquement

| Rôle | Identifiant | Mot de passe initial | Accès |
|---|---|---|---|
| **ADMIN** | `admin` | `2026@Ami@Pharma` | Tout (dashboard, approvisionnement, facturation, stock, inventaire, finance, utilisateurs, paramètres, audit) |
| **FINANCE** | `Finance` | `2026@Fin@Pharma` | Dashboard financier, situation, bilan, rapports financiers, lectures opérationnelles — ✗ utilisateurs, ✗ paramètres |
| **ASSISTANT** (démo) | `assistant` | `2026@Assist@Pharma` | Facturation, rapport journalier, stock, inventaire — ✗ finance, ✗ utilisateurs, ✗ approvisionnement |

> Les assistants pharmaciens supplémentaires se créent depuis **Utilisateurs → Nouvel utilisateur** (admin).
> Changez les mots de passe initiaux après la première connexion (menu profil → *Changer le mot de passe*).

### Arrêt / réinitialisation

```bash
docker compose down            # arrêt
docker compose down -v         # arrêt + suppression des données (volume PostgreSQL)
docker compose up --build -d   # redémarrage (le seed se relance si la base est vide)
```

---

### Dépannage Docker — « dependency failed to start: container amipharma-api is unhealthy »

**Cause racine identifiée (corrigée le 17/09/2026)** : les commandes Prisma passaient par `npx prisma`.
Si la CLI Prisma locale (`node_modules/.bin/prisma`, devDependency) est absente ou non résolue,
`npx` télécharge **silencieusement la dernière version majeure (Prisma 7+)** depuis le registre.
Prisma 7 rejette le schéma (`P1012 : datasource url no longer supported… prisma.config.ts`),
`prisma db push` échoue donc à chaque tentative, l'entrypoint se termine en erreur, `restart: unless-stopped`
relance le conteneur en boucle → le healthcheck n'aboutit jamais → **`amipharma-api is unhealthy`**.

**Le port 4000 occupé sur l'hôte n'est PAS une cause possible** : les conteneurs ont leur propre espace
réseau. Le healthcheck s'exécute **dans** `amipharma-api` (`wget 127.0.0.1:4000` = le conteneur lui-même)
et Nginx joint l'API via `http://api:4000` (DNS Docker interne). Un véritable conflit de port hôte
produirait d'ailleurs une erreur différente : `Bind for 0.0.0.0:XXXX failed: port is already allocated`
(avant même le démarrage du conteneur). Par précaution, l'API est publiée sur l'hôte en **4001**
(`API_PORT`), jamais sur 4000.

**Arbre de diagnostic si `api` reste unhealthy** — l'entrypoint affiche désormais la vraie erreur dès le
1er échec dans `docker compose logs api` :
- `✖ CLI Prisma locale introuvable` → image construite sans devDependencies : `docker compose build --no-cache api`
- `P1012 … prisma.config.ts` → une vieille image/cache utilise `npx` (Prisma 7) : rebuild `--no-cache`
- `P1001: Can't reach database server` → service `db` non prêt/réseau : `docker compose logs db`
- `P1010 / authentication failed` → mot de passe différent de celui stocké dans le volume `pgdata`
  (le volume conserve le mot de passe du **premier** initdb). Soit remettre l'ancien `POSTGRES_PASSWORD`
  dans `.env`, soit repartir de zéro **en connaissance de cause** : `docker compose down -v` (⚠ efface les données)
- Aucune de ces lignes → `docker inspect --format='{{json .State.Health}}' amipharma-api` pour voir la sortie du healthcheck

**Correctifs appliqués** (le healthcheck et `depends_on: service_healthy` sont **conservés** — ils révèlent le problème, ils ne le causent pas) :
- `backend/Dockerfile` : `npm ci` (installation déterministe, devDependencies incluses) au lieu de `npm install` ;
  `RUN node scripts/use-db.js postgres && ./node_modules/.bin/prisma generate` (binaire **local explicite**, jamais `npx`) ;
  `apk add openssl libc6-compat` (prérequis standard des moteurs Prisma sur Alpine/musl).
- `backend/docker-entrypoint.sh` : utilise `./node_modules/.bin/prisma` ; échoue **immédiatement** avec un message clair
  si la CLI est absente ; affiche le vrai log de `db push` après 30 tentatives (au lieu de `2>/dev/null`) ;
  affiche la version Prisma au démarrage ; seed tolérant aux pannes si la base est déjà initialisée.
- `backend/package.json` : `prisma` et `@prisma/client` **épinglés en version exacte `5.22.0`** (plus de `^`),
  lockfile régénéré → aucune dérive de version majeure possible.

**Commandes de validation** :
```bash
docker compose build --no-cache api
docker compose up -d
docker compose ps                    # amipharma-api doit finir par (healthy)
docker compose logs api | head -20   # doit afficher « Version Prisma utilisée : prisma : 5.22.0 »
wget -qO- http://localhost:8080/api/health   # via nginx → {"ok":true,...}
```
Si `api` reste unhealthy, `docker compose logs api` affiche désormais la **vraie** erreur (db push ou seed).

## 🧑‍💻 Développement local (sans Docker)

> **Démarrage en un seul script** (installe les dépendances manquantes, initialisé la base, démarre API + Web) :
> ```bash
> bash start-preview.sh
> ```

### Dépannage — HTTP 502/503 « Service backend injoignable » à la connexion

Ce message est un **symptôme exact** : le proxy (Vite en dev, Nginx en Docker, gateway de
prévisualisation) n'atteint pas l'API. Il n'apparaît QUE si l'API ne répond vraiment pas —
les identifiants incorrects renvoient toujours « Identifiants incorrects » (401).
Causes et vérifications dans l'ordre :

1. **L'API tourne-t-elle ?** `curl http://localhost:4000/api/health` (doit renvoyer `{"ok":true,…}`).
   * En dev/sandbox : les `node_modules` et les processus ne persistent pas après restauration → relancez `bash start-preview.sh` (tout réinstalle et redémarre en ~30 s).
   * Filet de sécurité : si `frontend/dist` existe, l'API sert aussi l'application complète sur le port 4000 (mode mono-process) — utile si Vite est arrêté.
   * En Docker : `docker compose ps` (le service `api` doit être `healthy`) puis `docker compose logs api`.
2. **La base est-elle accessible ?** `docker compose logs db` / en dev vérifier `backend/prisma/dev.db`.
3. **Les variables d'env sont-elles correctes ?** `DATABASE_URL`, `PORT`, secrets JWT (`.env`).
4. En Docker, Nginx attend que l'API soit **healthy** avant de démarrer
   (`depends_on: condition: service_healthy` + `HEALTHCHECK` sur `/api/health`, start-period 90 s
   pour couvrir migration + seed) et renvoie un JSON 503 explicite si l'API tombe ensuite.
   L'entrypoint API ne crash-loop plus si le seed échoue sur une base déjà initialisée.

```bash
# Backend (SQLite local ou PostgreSQL)
cd backend
npm install
node scripts/use-db.js sqlite        # ou: postgres
echo 'DATABASE_URL="file:./dev.db"' > .env
npx prisma generate && npx prisma db push
npm run seed                          # FORCE_SEED=1 pour réinitialiser les données de démo
npm run dev                           # API sur http://localhost:4000

# Frontend (autre terminal)
cd frontend
npm install
npm run dev                           # http://localhost:5173 (proxy /api → 4000)
```

---

## 📦 Architecture

```
ami-pharma/
├── docker-compose.yml          # db (PostgreSQL 16) + api (Node) + web (Nginx)
├── data/catalog.json           # 2 826 produits extraits du PDF LISTE DES PRIX(1).pdf
├── backend/                    # API REST — Node.js 20 + Express + Prisma
│   ├── Dockerfile / docker-entrypoint.sh
│   ├── prisma/
│   │   ├── schema.postgres.prisma   # production Docker
│   │   └── schema.sqlite.prisma     # développement local
│   ├── data/catalog.json
│   └── src/
│       ├── server.js           # Express + helmet + CORS + rate limiting
│       ├── config.js           # secrets, matrice de permissions par rôle
│       ├── middleware/         # auth JWT, RBAC, validation Zod, erreurs
│       ├── lib/                # prisma, jwt, stats (tous les calculs rapport)
│       ├── routes/             # auth, users, medicaments, catalog, fournisseurs,
│       │                       # approvisionnements, ventes, stock, inventaires,
│       │                       # rapports, dashboard, notifications, audit,
│       │                       # settings, exports (Excel/PDF/CSV + facture PDF)
│       └── seed/seed.js        # initialisation idempotente
└── frontend/                   # SPA — React 18 + TypeScript + Vite + Tailwind
    ├── Dockerfile / nginx.conf # build statique servi par Nginx, proxy /api
    └── src/
        ├── api/client.ts       # fetch + refresh token automatique
        ├── context/            # AuthContext (rôles/permissions), ToastContext
        ├── components/         # Layout (sidebar/topbar/notifications), UI, exports
        └── pages/              # 16 pages (dashboard, POS, stock, finance, …)
```

### Base de données (tables créées)

`users` · `roles` · `permissions` · `medicaments` · `categories` · `fournisseurs` · `price_catalog` ·
`approvisionnements` · `approvisionnement_items` (lots + expiration) · `ventes` · `vente_items` ·
`inventaires` · `inventaire_items` · `stock_movements` · `financial_transactions` · `daily_reports` ·
`notifications` · `audit_logs` · `clients` · `settings` — avec clés étrangères et **index** sur codes,
noms, numéros de facture, dates et stock.

### Règles de stock (transactionnelles)

```
Stock actuel = stock initial + approvisionnements − ventes ± ajustements d'inventaire
```

* Toute variation écrit un `stock_movement` (avant/après, référence, motif, utilisateur).
* Vente > stock disponible → **« Stock insuffisant »** (blocage, HTTP 409).
* Déduction FIFO par lot (date d'expiration la plus proche d'abord).
* Ajustement manuel → **motif obligatoire**, tracé dans l'audit.
* Suppression d'un produit ayant un historique comptable → refus, **archivage** proposé.
* Annulation de vente / d'approvisionnement → restauration automatique du stock.

---

## ✨ Fonctionnalités

| Module | Détails |
|---|---|
| **Tableau de bord** | 8 cartes statistiques, graphiques ventes/achats/marge, répartition du stock, tops & flops produits vendus/achetés, produits à réapprovisionner (qté suggérée = stock cible − stock actuel). Filtres : aujourd'hui / 7 j / 30 j / période personnalisée. **100 % dynamique depuis la base.** |
| **Approvisionnement** | Recherche instantanée stock + **catalogue PDF** (code, nom, désignation, emballage) avec récupération automatique des prix, bons multi-lignes, lots, dates d'expiration, calculs valeur achat/vente/marge, historique, annulation. |
| **Facturation (POS)** | Parcours : recherche → sélection → quantité → panier → paiement (Espèces / Mobile Money / Carte / Crédit) → facture. Numérotation auto **FAC-2026-000001**, monnaie, impression, **facture PDF** avec logo/en-tête/signature, déduction transactionnelle du stock. |
| **Gestion de stock** | Tableau temps réel : code, médicament, emballage, stock, min., prix, expiration, statut (🟢 normal · 🟠 faible · 🔴 épuisé · ⚠️ expiration proche · 🔴 expiré), bannières d'alerte, historique des mouvements par produit, ajustements motivés. |
| **Alertes d'expiration** | Seuils configurables (180/90/60/30 j par défaut), page dédiée : médicament, lot, date, quantité, jours restants, valeur du stock concerné. |
| **Inventaire** | Création (photo du stock théorique), saisie du stock physique, écart + valeur d'écart automatiques, surplus/déficit/manquant, validation → application au stock réel, historique complet. |
| **Rapport journalier** | Date, nb ventes, produits vendus, CA, achats, marge brute, paiements reçus, tops/flops, ruptures, stocks faibles, expirations proches, graphique 7 jours, filtres jour/semaine/mois/période. |
| **Rapport d'approvisionnement** | Priorités **URGENT** (stock = 0) / **ÉLEVÉ** (< minimum) / **NORMAL**, quantité recommandée, dernier prix d'achat, valeur estimée, fournisseur. Export Excel/PDF/CSV/impression. |
| **Finance** | Dashboard financier (CA, dépenses appro, valeur stock, marge, créances, résultat), **Situation financière** (filtres date/mois/année + exports), **Bilan** automatique (Actif : stock + trésorerie + créances / Passif : capitaux + dettes + résultat, extensible), **Rapport financier** avec évolutions. |
| **Utilisateurs & permissions** | 3 rôles (ADMIN / FINANCE / ASSISTANT), matrice ✓ / lecture / ✗ appliquée **côté serveur**, création/désactivation/suppression d'assistants, réinitialisation de mots de passe. |
| **Audit** | Connexions, créations, modifications, suppressions, ventes, annulations, inventaires, ajustements… avec utilisateur, date/heure, IP, anciennes/nouvelles valeurs (JSON). |
| **Notifications** | Cloche en barre supérieure : 🔴 épuisés · 🟠 stock faible · ⚠️ expirations < 30 j · 📦 réapprovisionnements · 💰 rapport financier — calculées en temps réel. |
| **Exports** | 🟢 Excel (.xlsx) · 🔴 PDF · ⚪ CSV · 🖨️ Impression — sur tous les tableaux et rapports (génération serveur ExcelJS / PDFKit). |
| **Catalogue PDF** | 2 826 produits importés **exactement** depuis `LISTE DES PRIX(1).pdf` (numéro, code, désignation, emballage, prix, CDF). Prix absent → affichage « Prix non défini » ; prix à 0 → « Prix = 0 CDF ». Fonction **Importer/actualiser le catalogue** (admin). |

---

## 🔐 Sécurité

* Mots de passe **hachés bcrypt (12 rounds)** — jamais en clair en base.
* **JWT** : access token (2 h) + refresh token (7 j) en cookie `httpOnly`.
* **RBAC** serveur sur chaque route (`requirePerm`), doublé dans l'UI.
* Helmet (en-têtes HTTP), CORS configurable, **rate limiting** (login + API).
* Requêtes paramétrées **Prisma** (protection injection SQL), échappement React (XSS), validation **Zod** de toutes les entrées.
* Journal d'audit horodaté avec IP.
* Limitation de débit : 30 tentatives de login / 15 min.

## 📱 Responsive

* **Ordinateur** : sidebar complète + dashboard détaillé.
* **Tablette** : sidebar rétractable, grilles adaptatives.
* **Smartphone** : menu hamburger (drawer), cartes empilées, tableaux à défilement horizontal.

## 🔮 Extensibilité prévue

Tables `clients` et `fournisseurs` déjà relationnelles, champs `roleId`/permissions en base, paramètres
devise/langue en `settings`, `ApprovisionnementItem.approvisionnementId` optionnel — prêts pour :
multi-pharmacies, plusieurs points de vente, ordonnances, dettes au bilan, devises et langues additionnelles.

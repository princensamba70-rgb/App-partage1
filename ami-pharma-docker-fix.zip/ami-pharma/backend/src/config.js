// Configuration centrale de l'API AMI PHARMA
import 'dotenv/config';

export const config = {
  port: parseInt(process.env.PORT || '4000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  jwt: {
    accessSecret: process.env.JWT_ACCESS_SECRET || 'ami-pharma-access-secret-change-me',
    refreshSecret: process.env.JWT_REFRESH_SECRET || 'ami-pharma-refresh-secret-change-me',
    accessTtl: process.env.JWT_ACCESS_TTL || '2h',
    refreshTtl: process.env.JWT_REFRESH_TTL || '7d',
  },
  corsOrigin: process.env.CORS_ORIGIN || '*',
  currency: process.env.CURRENCY || 'CDF',
  locale: process.env.LOCALE || 'fr-FR',
  pharmacy: {
    nom: 'AMI PHARMA',
    slogan: 'Système intégré de gestion de pharmacie',
    adresse: 'AVENUE NGUMA N° 3 Q/JOLI PARC C/NGALIEMA',
    ville: 'KINSHASA / RDC',
    telephone: '0820829592 - 0812271621',
  },
};

// Matrice de permissions par rôle (module → full | read | none)
export const PERMISSIONS = {
  ADMIN: {
    dashboard: 'full', approvisionnement: 'full', facturation: 'full',
    rapportJournalier: 'full', stock: 'full', inventaire: 'full',
    finance: 'full', utilisateurs: 'full', parametres: 'full',
    rapports: 'full', audit: 'full', medicaments: 'full', fournisseurs: 'full',
    catalogue: 'full',
  },
  FINANCE: {
    dashboard: 'read', approvisionnement: 'read', facturation: 'read',
    rapportJournalier: 'read', stock: 'read', inventaire: 'read',
    finance: 'full', utilisateurs: 'none', parametres: 'none',
    rapports: 'read', audit: 'none', medicaments: 'read', fournisseurs: 'read',
    catalogue: 'read',
  },
  ASSISTANT: {
    dashboard: 'read', approvisionnement: 'none', facturation: 'full',
    rapportJournalier: 'full', stock: 'full', inventaire: 'full',
    finance: 'none', utilisateurs: 'none', parametres: 'none',
    rapports: 'read', audit: 'none', medicaments: 'read', fournisseurs: 'none',
    catalogue: 'read',
  },
};

export const ROLES = { ADMIN: 'ADMIN', FINANCE: 'FINANCE', ASSISTANT: 'ASSISTANT' };

#!/usr/bin/env bash
# AMI PHARMA — démarrage complet de l'environnement de prévisualisation (sans Docker)
# Utile après une restauration du sandbox : les node_modules et les processus ne persistent pas.
# Usage : bash start-preview.sh
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"

echo "▶ [1/4] Dépendances backend…"
cd "$ROOT/backend"
[ -d node_modules ] || npm install --no-audit --no-fund
node scripts/use-db.js sqlite
[ -f node_modules/.prisma/client/index.js ] || npx prisma generate
[ -f prisma/dev.db ] || npx prisma db push

echo "▶ [2/4] Initialisation base (idempotent)…"
node src/seed/seed.js | tail -2

echo "▶ [3/4] Dépendances frontend…"
cd "$ROOT/frontend"
[ -d node_modules ] || npm install --no-audit --no-fund

echo "▶ [4/4] Démarrage API (:4000) puis Web (:5173)…"
(cd "$ROOT/backend" && nohup node src/server.js > /tmp/amipharma-api.log 2>&1 &)
sleep 2
curl -sf http://localhost:4000/api/health > /dev/null && echo "  ✔ API opérationnelle" || { echo "  ✖ API en échec — voir /tmp/amipharma-api.log"; exit 1; }
(cd "$ROOT/frontend" && nohup npm run dev > /tmp/amipharma-web.log 2>&1 &)
sleep 3
curl -sf -o /dev/null http://localhost:5173/ && echo "  ✔ Web opérationnel sur http://localhost:5173" || { echo "  ✖ Web en échec — voir /tmp/amipharma-web.log"; exit 1; }

echo "✅ AMI PHARMA prête — comptes : admin / Finance / assistant (voir README)"
